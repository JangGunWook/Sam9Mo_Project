import "./assets/js/nav-pills.js";
import "./assets/scss/soft-ui-dashboard.scss";

export default {
  install() {},
};

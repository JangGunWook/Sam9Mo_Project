<template>
  <default-dashboard />
</template>

<script>
import DefaultDashboard from "@/views/dashboards/Default.vue";
// import DefaultSignin from "@/views/SignIn/Default.vue";

// export default {
//   name: "HomPage",
//   components:{
//     DefaultSignin,
//   },
// };




export default {
  name: "HomePage",
  components: {
    DefaultDashboard,
  },
};
</script>
